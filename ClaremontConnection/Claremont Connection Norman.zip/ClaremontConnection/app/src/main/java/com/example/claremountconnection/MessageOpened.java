package com.example.claremountconnection;

public class MessageOpened {
}
